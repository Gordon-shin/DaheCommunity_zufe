create definer = dahe@`%` view view_shop_invoice as
select `dahe`.`tb_shop_items_invoices`.`Id`          AS `Id`,
       `dahe`.`tb_shop_items_invoices`.`userId`      AS `userid`,
       `dahe`.`tb_shop_items_invoices`.`invoiceDate` AS `invoiceDate`,
       `dahe`.`tb_shop_items`.`ItemId`               AS `itemId`,
       `dahe`.`tb_shop_items`.`ItemName`             AS `ItemName`,
       `dahe`.`tb_shop_items`.`offerUserId`          AS `offerUserId`,
       `dahe`.`tb_shop_items_invoices`.`itemNumber`  AS `itemNumber`,
       `dahe`.`tb_shop_items_invoices`.`total`       AS `total`,
       `dahe`.`tb_shop_items_invoices`.`state`       AS `state`
from (`dahe`.`tb_shop_items_invoices`
       left join `dahe`.`tb_shop_items`
                 on ((`dahe`.`tb_shop_items`.`ItemId` = `dahe`.`tb_shop_items_invoices`.`itemId`)));

