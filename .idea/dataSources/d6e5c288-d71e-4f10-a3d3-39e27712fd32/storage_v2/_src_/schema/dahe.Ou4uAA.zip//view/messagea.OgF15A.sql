create view messagea as
select `dahe`.`tb_dialog`.`Id`            AS `Id`,
       `dahe`.`tb_dialog`.`beginTime`     AS `beginTime`,
       `dahe`.`tb_dialog`.`diaguser`      AS `diaguser`,
       `dahe`.`tb_users`.`UserPersonName` AS `UserPersonName`
from (`dahe`.`tb_dialog`
       join `dahe`.`tb_users`)
where (`dahe`.`tb_users`.`UserId` = `dahe`.`tb_dialog`.`diaguser`);

