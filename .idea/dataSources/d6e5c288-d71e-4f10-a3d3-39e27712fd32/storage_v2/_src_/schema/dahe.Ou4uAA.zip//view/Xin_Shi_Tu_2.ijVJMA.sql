create definer = dahe@`%` view 新视图2 as
select `dahe`.`tb_shop_items_invoices`.`Id`          AS `id`,
       `dahe`.`tb_shop_items_invoices`.`invoiceDate` AS `invoiceDate`,
       `dahe`.`tb_shop_items_invoices`.`userId`      AS `userId`,
       `dahe`.`tb_shop_items`.`ItemId`               AS `itemId`,
       `dahe`.`tb_shop_items_invoices`.`total`       AS `total`,
       `dahe`.`tb_shop_items_invoices`.`itemNumber`  AS `itemNumber`,
       `dahe`.`tb_shop_items_invoices`.`state`       AS `state`,
       `dahe`.`tb_shop_items`.`ItemName`             AS `ItemName`,
       `dahe`.`tb_shop_items_invoices`.`itemPrice`   AS `ItemPrice`
from (`dahe`.`tb_shop_items_invoices`
       join `dahe`.`tb_shop_items`)
where (`dahe`.`tb_shop_items`.`ItemId` = `dahe`.`tb_shop_items_invoices`.`itemId`);

