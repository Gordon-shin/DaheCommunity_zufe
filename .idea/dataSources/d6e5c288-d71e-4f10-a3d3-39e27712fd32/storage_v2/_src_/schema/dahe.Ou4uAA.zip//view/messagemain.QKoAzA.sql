create definer = dahe@`%` view messagemain as
select `messagea`.`Id`             AS `id`,
       `messagea`.`beginTime`      AS `begintime`,
       `messagea`.`diaguser`       AS `diaguser`,
       `messagea`.`UserPersonName` AS `userpersonname`,
       `messageb`.`contactUserId`  AS `contactuserid`,
       `messageb`.`UserPersonName` AS `userpersonname2`
from (`dahe`.`messagea`
       join `dahe`.`messageb` on ((`messageb`.`Id` = `messagea`.`Id`)));

